<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
//require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

/**
 * This is an code of a few basic user interaction methods
 * all done
 *
 * @package         CodeIgniter
 * @subpackage      aref24 Project
 * @category        Controller
 * @author          Mohammad Hoseini, Abolfazl Ganji
 * @license         MIT
 * @link            https://aref24.ir
 */
class Kindsenddamagefile extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
    }

    public function index_post()
    {
        if(isset($this->input->request_headers()['Authorization']))$employee_token_str = $this->input->request_headers()['Authorization'];
        $this->load->model('B_user');
        $this->load->model('B_db');
        $this->load->model('B_expert');
        $this->load->helper('my_helper');
        $command = $this->post("command");
        if($this->B_user->checkrequestip('kindsenddamagefile',$command,get_client_ip(),50,50)){
        if ($command=="add_kindsenddamagefile")
        {


            $kindsenddamagefile_state_id=$this->post('kindsenddamagefile_state_id');

            $kindsenddamagefile_city_id=$this->post('kindsenddamagefile_city_id');

            $kindsenddamagefile_kind_id=$this->post('kindsenddamagefile_kind_id');

            $kindsenddamagefile_expert_id=$this->post('kindsenddamagefile_expert_id');

            $kindsenddamagefile_evaluatorco_id=$this->post('kindsenddamagefile_evaluatorco_id');

            $kindsenddamagefile_fielddamagefile_id=$this->post('kindsenddamagefile_fielddamagefile_id');





            $employeetoken=checkpermissionemployeetoken($employee_token_str,'new','kindsenddamagefile');
            if($employeetoken[0]=='ok')
            {
//************************************************************************;****************************************
                $query="select * from kindsenddamagefile_tb where kindsenddamagefile_state_id=".$kindsenddamagefile_state_id." AND kindsenddamagefile_city_id=".$kindsenddamagefile_city_id."  AND kindsenddamagefile_evaluatorco_id=".$kindsenddamagefile_evaluatorco_id." AND kindsenddamagefile_fielddamagefile_id=".$kindsenddamagefile_fielddamagefile_id."";
                $result=$this->B_db->run_query($query);
                $num=count($result[0]);
                if ($num==0)
                {
                    $query1="INSERT INTO kindsenddamagefile_tb(kindsenddamagefile_state_id,  kindsenddamagefile_city_id,  kindsenddamagefile_kind_id,  kindsenddamagefile_expert_id  ,  kindsenddamagefile_evaluatorco_id ,  kindsenddamagefile_fielddamagefile_id)
	                                 VALUES ($kindsenddamagefile_state_id, $kindsenddamagefile_city_id,$kindsenddamagefile_kind_id,$kindsenddamagefile_expert_id, $kindsenddamagefile_evaluatorco_id, $kindsenddamagefile_fielddamagefile_id);";

                    $result1=$this->B_db->run_query_put($query1);
                    $kindsenddamagefile_id=$this->db->insert_id();




                    echo json_encode(array('result'=>"ok"
                    ,"data"=>array('kindsenddamagefile_id'=>$kindsenddamagefile_id)
                    ,'desc'=>'نوع ارسال در منطقه مورد نظر اضافه شد'.$query1),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                }else{
                    $carmode=$result[0];
                    echo json_encode(array('result'=>"error"
                    ,"data"=>array('kindsenddamagefile_id'=>$carmode['kindsenddamagefile_id'])
                    ,'desc'=>'نوع ارسال در منطقه مورد نظر تکراری است'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                }
//***************************************************************************************************************
            }else{
                echo json_encode(array('result'=>$employeetoken[0]
                ,"data"=>$employeetoken[1]
                ,'desc'=>$employeetoken[2]));

            }






        }
        else
            if ($command=="get_senddamagefile_kind")
            {

                $employeetoken=checkpermissionemployeetoken($employee_token_str,'view','kindsenddamagefile');
                if($employeetoken[0]=='ok')
                {
//***************************************************************************************************************

                    $query="select * from senddamagefile_kind_tb";
                    $result = $this->B_db->run_query($query);
                    $output =array();
                    foreach($result as $row)
                    {
                        $record['senddamagefile_kind_id']=$row['senddamagefile_kind_id'];
                        $record['senddamagefile_kind_name']=$row['senddamagefile_kind_name'];

                        $output[]=$record;
                    }
                    echo json_encode(array('result'=>"ok"
                    ,"data"=>$output
                    ,'desc'=>'مشحصات نوع ارسال با  موفقیت ارسال شد'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
//***************************************************************************************************************
                }else{
                    echo json_encode(array('result'=>$employeetoken[0]
                    ,"data"=>$employeetoken[1]
                    ,'desc'=>$employeetoken[2]));

                }


            }
            else
                if ($command=="get_kindsenddamagefile")
                {

                    $employeetoken=checkpermissionemployeetoken($employee_token_str,'view','kindsenddamagefile');
                    if($employeetoken[0]=='ok')
                    {

//************************************************************************;****************************************

                        $query="select * from kindsenddamagefile_tb,evaluatorco_tb,expert_tb,senddamagefile_kind_tb where kindsenddamagefile_kind_id=senddamagefile_kind_id AND kindsenddamagefile_expert_id=expert_id AND evaluatorco_id=kindsenddamagefile_evaluatorco_id AND ";
                        if(isset($_damagefile['kindsenddamagefile_state_id'])){
                            $kindsenddamagefile_state_id=$this->post('kindsenddamagefile_state_id') ;
                            $query.=" kindsenddamagefile_state_id=$kindsenddamagefile_state_id ";
                        }else{$query.=" 1=1 ";}
                        $query.=" AND ";
                        if(isset($_damagefile['kindsenddamagefile_city_id'])){
                            $kindsenddamagefile_city_id=$this->post('kindsenddamagefile_city_id') ;
                            $query.=" kindsenddamagefile_city_id=$kindsenddamagefile_city_id ";
                        }else{$query.=" 1=1 ";}
                        $query.=" AND ";
                        if(isset($_damagefile['kindsenddamagefile_evaluatorco_id'])){
                            $kindsenddamagefile_evaluatorco_id=$this->post('kindsenddamagefile_evaluatorco_id') ;
                            $query.=" kindsenddamagefile_evaluatorco_id=$kindsenddamagefile_evaluatorco_id ";
                        }else{$query.=" 1=1 ";}

                        $query.=" ORDER BY kindsenddamagefile_id ASC";

                        $result = $this->B_db->run_query($query);
                        $output =array();
                        foreach($result as $row)
                        {
                            $record=array();
                            $record['kindsenddamagefile_id']=$row['kindsenddamagefile_id'];
                            $record['evaluatorco_id']=$row['evaluatorco_id'];
                            $record['expert_evaluatorco_name']=$row['evaluatorco_name'];
                            $record['expert_evaluatorco_logo_url']=IMGADD.$row['evaluatorco_logo_url'];
                            $record['kindsenddamagefile_state_id']=$row['kindsenddamagefile_state_id'];
                            $record['kindsenddamagefile_city_id']=$row['kindsenddamagefile_city_id'];
                            $record['kindsenddamagefile_fielddamagefile_id']=$row['kindsenddamagefile_fielddamagefile_id'];

                            if($record['kindsenddamagefile_city_id']=='0'){
                                $record['expert_city_name']='همه شهر ها';
                            }else{
                                $query1=" SELECT * FROM city_tb WHERE city_id=".$row['kindsenddamagefile_city_id']."";
                                $result1=$this->B_db->run_query($query1);
                                $city=$result1[0];

                                $record['expert_city_name']=$city['city_name'];
                            }

                            if($record['kindsenddamagefile_state_id']=='0'){
                                $record['expert_state_name']='همه استان ها';
                            }else{
                                $query1=" SELECT * FROM state_tb WHERE state_id=".$row['kindsenddamagefile_state_id']."";
                                $result1=$this->B_db->run_query($query1);
                                $state=$result1[0];

                                $record['expert_state_name']=$state['state_name'];
                            }

                            if($record['kindsenddamagefile_fielddamagefile_id']=='0'){
                                $record['fielddamagefile_name']='همه رشته ها';
                            }else{
                                $query1=" SELECT * FROM fielddamagefile_tb WHERE fielddamagefile_id=".$row['kindsenddamagefile_fielddamagefile_id']."";
                                $result1=$this->B_db->run_query($query1);
                                $fielddamagefile=$result1[0];

                                $record['fielddamagefile_name']=$fielddamagefile['fielddamagefile_fa'];
                                $record['fielddamagefile_logo_url']=IMGADD.$fielddamagefile['fielddamagefile_logo_url'];
                            }

                            $record['kindsenddamagefile_kind_id']=$row['kindsenddamagefile_kind_id'];
                            $record['senddamagefile_kind_name']=$row['senddamagefile_kind_name'];
                            $record['kindsenddamagefile_expert_id']=$row['kindsenddamagefile_expert_id'];
                            $record['expert_name']=$row['expert_name'];
                            $record['expert_family']=$row['expert_family'];
                            $record['expert_gender']=$row['expert_gender'];
                            $record['expert_mobile']=$row['expert_mobile'];
                            $record['expert_code']=$row['expert_code'];

                            $output[]=$record;
                        }
                        echo json_encode(array('result'=>"ok"
                        ,"data"=>$output
                        ,'desc'=>"نوع توزیع درخواست ها با موفقیت ارسال شد"));
//***************************************************************************************************************
                    }else{
                        echo json_encode(array('result'=>$employeetoken[0]
                        ,"data"=>$employeetoken[1]
                        ,'desc'=>$employeetoken[2]));

                    }

                }
                else
                    if ($command=="delete_kindsenddamagefile")
                    {
                        $kindsenddamagefile_id=$this->post('kindsenddamagefile_id');
                        $employeetoken=checkpermissionemployeetoken($employee_token_str,'delete','kindsenddamagefile');
                        if($employeetoken[0]=='ok')
                        {
                            $output = array();$user_id=$employeetoken[0];
                            $query="DELETE FROM kindsenddamagefile_tb  where kindsenddamagefile_id=".$kindsenddamagefile_id."";
                            $result = $this->B_db->run_query_put($query);
                            if($result){echo json_encode(array('result'=>"ok"
                            ,"data"=>$output
                            ,'desc'=>'نماینده مورد نظر حذف شد'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                            }else{
                                echo json_encode(array('result'=>"error"
                                ,"data"=>$output
                                ,'desc'=>'نماینده مورد نظر حذف نشد'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                            }
//***************************************************************************************************************
                        }else{
                            echo json_encode(array('result'=>$employeetoken[0]
                            ,"data"=>$employeetoken[1]
                            ,'desc'=>$employeetoken[2]));

                        }
                    }
                    else
                        if ($command=="modify_kindsenddamagefile") {
                            $kindsenddamagefile_id = $this->post('kindsenddamagefile_id');

                            $employeetoken = checkpermissionemployeetoken($employee_token_str, 'modify', 'kindsenddamagefile');
                            if ($employeetoken[0] == 'ok') {
//*****************************************************************************************

                                $query="UPDATE kindsenddamagefile_tb SET ";
                                if (isset($_damagefile['kindsenddamagefile_state_id'])) {
                                    $kindsenddamagefile_state_id = $this->post('kindsenddamagefile_state_id');
                                    $query .= "kindsenddamagefile_state_id=" . $kindsenddamagefile_state_id . " ";
                                }

                                if (isset($_damagefile['kindsenddamagefile_city_id']) && (isset($_damagefile['kindsenddamagefile_state_id']))) {
                                    $query .= ",";
                                }
                                if (isset($_damagefile['kindsenddamagefile_city_id'])) {
                                    $kindsenddamagefile_city_id = $this->post('kindsenddamagefile_city_id');
                                    $query .= "kindsenddamagefile_city_id=" . $kindsenddamagefile_city_id . " ";
                                }

                                if (isset($_damagefile['kindsenddamagefile_kind_id']) && (isset($_damagefile['kindsenddamagefile_state_id']) || isset($_damagefile['kindsenddamagefile_city_id']))) {
                                    $query .= ",";
                                }
                                if (isset($_damagefile['kindsenddamagefile_kind_id'])) {
                                    $kindsenddamagefile_kind_id = $this->post('kindsenddamagefile_kind_id');
                                    $query .= "kindsenddamagefile_kind_id=" . $kindsenddamagefile_kind_id . " ";
                                }

                                if (isset($_damagefile['kindsenddamagefile_expert_id']) && (isset($_damagefile['kindsenddamagefile_kind_id']) || isset($_damagefile['kindsenddamagefile_state_id']) || isset($_damagefile['kindsenddamagefile_city_id']))) {
                                    $query .= ",";
                                }
                                if (isset($_damagefile['kindsenddamagefile_expert_id'])) {
                                    $kindsenddamagefile_expert_id = $this->post('kindsenddamagefile_expert_id');
                                    $query .= "kindsenddamagefile_expert_id=" . $kindsenddamagefile_expert_id . " ";
                                }

                                if (isset($_damagefile['kindsenddamagefile_evaluatorco_id']) && (isset($_damagefile['kindsenddamagefile_expert_id']) || isset($_damagefile['kindsenddamagefile_kind_id']) || isset($_damagefile['kindsenddamagefile_state_id']) || isset($_damagefile['kindsenddamagefile_city_id']))) {
                                    $query .= ",";
                                }
                                if (isset($_damagefile['kindsenddamagefile_evaluatorco_id'])) {
                                    $kindsenddamagefile_evaluatorco_id = $this->post('kindsenddamagefile_evaluatorco_id');
                                    $query .= "kindsenddamagefile_evaluatorco_id=" . $kindsenddamagefile_evaluatorco_id . " ";
                                }

                                if (isset($_damagefile['kindsenddamagefile_fielddamagefile_id']) && (isset($_damagefile['kindsenddamagefile_evaluatorco_id']) || isset($_damagefile['kindsenddamagefile_expert_id']) || isset($_damagefile['kindsenddamagefile_kind_id']) || isset($_damagefile['kindsenddamagefile_state_id']) || isset($_damagefile['kindsenddamagefile_city_id']))) {
                                    $query .= ",";
                                }
                                if (isset($_damagefile['kindsenddamagefile_fielddamagefile_id'])) {
                                    $kindsenddamagefile_fielddamagefile_id = $this->post('kindsenddamagefile_fielddamagefile_id');
                                    $query .= "kindsenddamagefile_fielddamagefile_id=" . $kindsenddamagefile_fielddamagefile_id . " ";
                                }

                                $query .= "where kindsenddamagefile_id=" . $kindsenddamagefile_id;

                                $result = $this->B_db->run_query_put($query);


                                if ($result) {
                                    echo json_encode(array('result' => "ok"
                                    , "data" => ""
                                    , 'desc' => ' تغییرات انجام شد'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                                } else {
                                    echo json_encode(array('result' => "ok"
                                    , "data" => ""
                                    , 'desc' => 'تغییرات انجام نشد'),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                                }
                            } else {
                                echo json_encode(array('result' => $employeetoken[0]
                                , "data" => $employeetoken[1]
                                , 'desc' => $employeetoken[2]));

                            }


                        }
                        }
}
}